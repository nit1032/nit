𝗩𝗘𝗡𝗢𝗠 𝗩2 𝗦𝗖𝗥𝗶𝗣𝗧(𝗢𝗡 𝗧𝗘𝗦𝗧𝗶𝗡𝗚)

𝐇𝐨𝐰 𝐓𝐨 𝐔𝐬𝐞✓𝚏𝚘𝚕𝚕𝚘𝚠 𝚊𝚕𝚕 𝚜𝚝𝚎𝚙𝚜 
𝚘𝚗𝚎 𝚋𝚢 𝚘𝚗𝚎

»Create a group 
»Public that group
»Add @MissRose_bot in group
»Add your ddos bot in group
»Make admin to miss rose and your ddos bot
»Type /id in group (ʏᴏᴜ ᴡɪʟʟ ɢᴇᴛ ᴀ ɪᴅ ᴄᴏᴘʏ ᴛʜᴀᴛ ɢʀᴏᴜᴘ ɪᴅ )

»Open repo
»Fork repo 
»Go to venom.py edit'
»Add bot token in line-19
»Add group id in line 21 22 and 23

»Now save file by Commit changes
»Go to codespace 
»Select repo yourgitusernam/venom2
»Select 4core
»Create codespace
»Install python
»Open terminal and run following commands- https://t.me/venomCHA7/27952

1. pip install telebot

2. pip install pymongo aiohttp telebot

3. Chmod +x *

4. python venom.py

𝐁𝐨𝐨𝐌 𝐁𝐨𝐓 𝐢𝐒 𝐒𝐓𝐚𝐫𝐓𝐞𝐃 ☻︎

Go to the group and approve yourself to use ddos by»
/approve  5588464519 1

𝚗𝚘𝚘𝚋𝚜 𝚠𝚊𝚝𝚌𝚑 𝚝𝚑𝚒𝚜 𝚟𝚒𝚍𝚎𝚘» https://t.me/venomCHA7/28089

note-  𝗩𝗘𝗡𝗢𝗠 𝗩2 𝗦𝗖𝗥𝗶𝗣𝗧(𝗢𝗡 𝗧𝗘𝗦𝗧𝗶𝗡𝗚)
This script will not run but 24x7 and more features are not added yet i will add all features soon keep support.
Bgmi anticheat got fucked in this script account ban chance decreased by 70%

                    bgmi»🤡
